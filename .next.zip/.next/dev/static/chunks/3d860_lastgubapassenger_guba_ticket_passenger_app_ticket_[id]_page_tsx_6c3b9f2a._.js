(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_lastgubapassenger_guba_ticket_passenger_0ff2ca2a._.js",
  "static/chunks/cfcca_7c690a4f._.js"
],
    source: "dynamic"
});
