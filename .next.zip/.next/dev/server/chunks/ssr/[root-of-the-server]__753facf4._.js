module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/searchSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "resetSearch",
    ()=>resetSearch,
    "searchSlice",
    ()=>searchSlice,
    "setDepartureDate",
    ()=>setDepartureDate,
    "setDestination",
    ()=>setDestination,
    "setOrigin",
    ()=>setOrigin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
;
const initialState = {
    origin: '',
    destination: '',
    departureDate: ''
};
const searchSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'search',
    initialState,
    reducers: {
        setOrigin: (state, action)=>{
            state.origin = action.payload;
        },
        setDestination: (state, action)=>{
            state.destination = action.payload;
        },
        setDepartureDate: (state, action)=>{
            state.departureDate = action.payload;
        },
        resetSearch: (state)=>{
            state.origin = '';
            state.destination = '';
            state.departureDate = '';
        }
    }
});
const { setOrigin, setDestination, setDepartureDate, resetSearch } = searchSlice.actions;
const __TURBOPACK__default__export__ = searchSlice.reducer;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/citySlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "citySlice",
    ()=>citySlice,
    "clearCities",
    ()=>clearCities,
    "default",
    ()=>__TURBOPACK__default__export__,
    "fetchCities",
    ()=>fetchCities
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
;
const initialState = {
    cities: [],
    pagination: null,
    loading: false,
    error: null
};
const fetchCities = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('city/fetchCities', async ({ pageNumber = 1, pageSize = 200, searchKeyword = '' })=>{
    const response = await fetch(`${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/public/city/list?PageNumber=${pageNumber}&PageSize=${pageSize}&searchKeyword=${searchKeyword}`);
    const data = await response.json();
    return data.data;
});
const citySlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'city',
    initialState,
    reducers: {
        clearCities: (state)=>{
            state.cities = [];
            state.pagination = null;
            state.error = null;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(fetchCities.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchCities.fulfilled, (state, action)=>{
            state.loading = false;
            state.cities = action.payload.cities;
            state.pagination = action.payload.pagination;
        }).addCase(fetchCities.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.error.message || 'Failed to fetch cities';
        });
    }
});
const { clearCities } = citySlice.actions;
const __TURBOPACK__default__export__ = citySlice.reducer;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/tripSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearTripDetails",
    ()=>clearTripDetails,
    "clearTrips",
    ()=>clearTrips,
    "default",
    ()=>__TURBOPACK__default__export__,
    "getTripDetails",
    ()=>getTripDetails,
    "searchTrips",
    ()=>searchTrips,
    "tripSlice",
    ()=>tripSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
;
const initialState = {
    trips: [],
    pagination: null,
    loading: false,
    error: null,
    tripDetails: null,
    detailsLoading: false,
    detailsError: null
};
const searchTrips = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('trip/searchTrips', async ({ originGuid, destinationGuid, travelDate, pageNumber = 1, pageSize = 10, busCarrierGuid })=>{
    let url = `${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/public/trip/search?originGuid=${originGuid}&destinationGuid=${destinationGuid}&travelDate=${travelDate}&PageNumber=${pageNumber}&PageSize=${pageSize}`;
    if (busCarrierGuid) {
        url += `&busCarrierGuid=${busCarrierGuid}`;
    }
    const response = await fetch(url);
    const data = await response.json();
    if (response.status === 404) {
        return {
            trips: [],
            pagination: null
        };
    }
    return data.data;
});
const getTripDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('trip/getTripDetails', async (tripId)=>{
    const response = await fetch(`${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/public/trip/details?id=${tripId}`);
    const data = await response.json();
    return data.data.trip;
});
const tripSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'trip',
    initialState,
    reducers: {
        clearTrips: (state)=>{
            state.trips = [];
            state.pagination = null;
            state.error = null;
        },
        clearTripDetails: (state)=>{
            state.tripDetails = null;
            state.detailsError = null;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(searchTrips.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(searchTrips.fulfilled, (state, action)=>{
            state.loading = false;
            state.trips = action.payload.trips;
            state.pagination = action.payload.pagination;
        }).addCase(searchTrips.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.error.message || 'Failed to search trips';
        }).addCase(getTripDetails.pending, (state)=>{
            state.detailsLoading = true;
            state.detailsError = null;
        }).addCase(getTripDetails.fulfilled, (state, action)=>{
            state.detailsLoading = false;
            state.tripDetails = action.payload;
        }).addCase(getTripDetails.rejected, (state, action)=>{
            state.detailsLoading = false;
            state.detailsError = action.error.message || 'Failed to get trip details';
        });
    }
});
const { clearTrips, clearTripDetails } = tripSlice.actions;
const __TURBOPACK__default__export__ = tripSlice.reducer;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/busCarrierSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "busCarrierSlice",
    ()=>busCarrierSlice,
    "clearBusCarriers",
    ()=>clearBusCarriers,
    "default",
    ()=>__TURBOPACK__default__export__,
    "fetchBusCarriers",
    ()=>fetchBusCarriers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
;
const initialState = {
    busCarriers: [],
    pagination: null,
    loading: false,
    error: null
};
const fetchBusCarriers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('busCarrier/fetchBusCarriers', async ({ pageNumber = 1, pageSize = 100, searchKeyword = '' } = {})=>{
    const response = await fetch(`${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/public/bus-carrier/list?PageNumber=${pageNumber}&PageSize=${pageSize}&searchKeyword=${searchKeyword}`);
    const data = await response.json();
    return data.data;
});
const busCarrierSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'busCarrier',
    initialState,
    reducers: {
        clearBusCarriers: (state)=>{
            state.busCarriers = [];
            state.pagination = null;
            state.error = null;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(fetchBusCarriers.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchBusCarriers.fulfilled, (state, action)=>{
            state.loading = false;
            state.busCarriers = action.payload.busCarriers;
            state.pagination = action.payload.pagination;
        }).addCase(fetchBusCarriers.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.error.message || 'Failed to fetch bus carriers';
        });
    }
});
const { clearBusCarriers } = busCarrierSlice.actions;
const __TURBOPACK__default__export__ = busCarrierSlice.reducer;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/bookingSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bookTicket",
    ()=>bookTicket,
    "bookingSlice",
    ()=>bookingSlice,
    "clearBooking",
    ()=>clearBooking,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
;
const initialState = {
    booking: null,
    loading: false,
    error: null
};
const bookTicket = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('booking/bookTicket', async (bookingData, { getState })=>{
    const state = getState();
    const token = state.auth.token;
    const response = await fetch(`${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/passenger/trip/ticket/book`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(bookingData)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message);
    return data.data.booking;
});
const bookingSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'booking',
    initialState,
    reducers: {
        clearBooking: (state)=>{
            state.booking = null;
            state.error = null;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(bookTicket.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(bookTicket.fulfilled, (state, action)=>{
            state.loading = false;
            state.booking = action.payload;
        }).addCase(bookTicket.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.error.message || 'Failed to book ticket';
        });
    }
});
const { clearBooking } = bookingSlice.actions;
const __TURBOPACK__default__export__ = bookingSlice.reducer;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/authSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authSlice",
    ()=>authSlice,
    "clearError",
    ()=>clearError,
    "default",
    ()=>__TURBOPACK__default__export__,
    "getProfile",
    ()=>getProfile,
    "loadFromStorage",
    ()=>loadFromStorage,
    "login",
    ()=>login,
    "logout",
    ()=>logout,
    "register",
    ()=>register
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
;
const initialState = {
    user: null,
    token: ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : null,
    loading: false,
    error: null,
    isAuthenticated: false
};
const login = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('auth/login', async (loginData)=>{
    const response = await fetch(`${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/auth/passenger/login`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(loginData)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message);
    return data.data.token;
});
const register = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('auth/register', async (registerData)=>{
    const response = await fetch(`${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/auth/passenger/register`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(registerData)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message);
    return data.data.passenger;
});
const getProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('auth/getProfile', async (_, { getState })=>{
    const state = getState();
    const token = state.auth.token;
    const response = await fetch(`${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/passenger/profile/details`, {
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message);
    return data.data.passenger;
});
const authSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'auth',
    initialState,
    reducers: {
        logout: (state)=>{
            state.user = null;
            state.token = null;
            state.isAuthenticated = false;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        },
        clearError: (state)=>{
            state.error = null;
        },
        loadFromStorage: (state)=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(login.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(login.fulfilled, (state, action)=>{
            state.loading = false;
            state.token = action.payload;
            state.isAuthenticated = true;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }).addCase(login.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.error.message || 'Login failed';
        }).addCase(register.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(register.fulfilled, (state)=>{
            state.loading = false;
        }).addCase(register.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.error.message || 'Registration failed';
        }).addCase(getProfile.fulfilled, (state, action)=>{
            state.user = action.payload;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        });
    }
});
const { logout, clearError, loadFromStorage } = authSlice.actions;
const __TURBOPACK__default__export__ = authSlice.reducer;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/ticketSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearSearchResults",
    ()=>clearSearchResults,
    "clearTicketDetail",
    ()=>clearTicketDetail,
    "clearTickets",
    ()=>clearTickets,
    "default",
    ()=>__TURBOPACK__default__export__,
    "fetchTicketDetail",
    ()=>fetchTicketDetail,
    "fetchTickets",
    ()=>fetchTickets,
    "searchTicketByPNR",
    ()=>searchTicketByPNR,
    "ticketSlice",
    ()=>ticketSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
;
const initialState = {
    tickets: [],
    pagination: null,
    loading: false,
    error: null,
    searchResults: [],
    searchPagination: null,
    searchLoading: false,
    searchError: null,
    ticketDetail: null,
    detailLoading: false,
    detailError: null
};
const fetchTickets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('ticket/fetchTickets', async ({ pageNumber = 1, pageSize = 8, status = '' }, { getState })=>{
    const state = getState();
    const token = state.auth.token;
    let url = `${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/passenger/trip/ticket/list?PageNumber=${pageNumber}&PageSize=${pageSize}`;
    if (status) {
        url += `&status=${status}`;
    }
    const response = await fetch(url, {
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message);
    return data.data;
});
const searchTicketByPNR = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('ticket/searchByPNR', async ({ searchQuery, pageNumber = 1, pageSize = 8 })=>{
    const url = `${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/public/trip/ticket/search?PageNumber=${pageNumber}&PageSize=${pageSize}&searchQuery=${searchQuery}`;
    const response = await fetch(url, {
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message);
    return data.data;
});
const fetchTicketDetail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('ticket/fetchDetail', async (ticketGuid, { getState })=>{
    const state = getState();
    const token = state.auth.token;
    const url = `${("TURBOPACK compile-time value", "http://196.190.220.187:8081/api")}/passenger/trip/ticket/details?id=${ticketGuid}`;
    const response = await fetch(url, {
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message);
    return data.data.ticket;
});
const ticketSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'ticket',
    initialState,
    reducers: {
        clearTickets: (state)=>{
            state.tickets = [];
            state.pagination = null;
            state.error = null;
        },
        clearSearchResults: (state)=>{
            state.searchResults = [];
            state.searchPagination = null;
            state.searchError = null;
        },
        clearTicketDetail: (state)=>{
            state.ticketDetail = null;
            state.detailError = null;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(fetchTickets.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchTickets.fulfilled, (state, action)=>{
            state.loading = false;
            state.tickets = action.payload.tickets;
            state.pagination = action.payload.pagination;
        }).addCase(fetchTickets.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.error.message || 'Failed to fetch tickets';
        }).addCase(searchTicketByPNR.pending, (state)=>{
            state.searchLoading = true;
            state.searchError = null;
        }).addCase(searchTicketByPNR.fulfilled, (state, action)=>{
            state.searchLoading = false;
            state.searchResults = action.payload.bookings;
            state.searchPagination = action.payload.pagination;
        }).addCase(searchTicketByPNR.rejected, (state, action)=>{
            state.searchLoading = false;
            state.searchError = action.error.message || 'Failed to search ticket';
        }).addCase(fetchTicketDetail.pending, (state)=>{
            state.detailLoading = true;
            state.detailError = null;
        }).addCase(fetchTicketDetail.fulfilled, (state, action)=>{
            state.detailLoading = false;
            state.ticketDetail = action.payload;
        }).addCase(fetchTicketDetail.rejected, (state, action)=>{
            state.detailLoading = false;
            state.detailError = action.error.message || 'Failed to fetch ticket details';
        });
    }
});
const { clearTickets, clearSearchResults, clearTicketDetail } = ticketSlice.actions;
const __TURBOPACK__default__export__ = ticketSlice.reducer;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/store.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "makeStore",
    ()=>makeStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$searchSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/searchSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$citySlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/citySlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$tripSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/tripSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$busCarrierSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/busCarrierSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$bookingSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/bookingSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$authSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/authSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$ticketSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/features/ticketSlice.ts [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
const makeStore = ()=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["configureStore"])({
        reducer: {
            search: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$searchSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            city: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$citySlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            trip: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$tripSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            busCarrier: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$busCarrierSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            booking: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$bookingSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            auth: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$authSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            ticket: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$features$2f$ticketSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
        }
    });
};
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/StoreProvider.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StoreProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/store.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
function StoreProvider({ children }) {
    const storeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    if (!storeRef.current) {
        storeRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$lib$2f$redux$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["makeStore"])();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Provider"], {
        store: storeRef.current,
        children: children
    }, void 0, false, {
        fileName: "[project]/Desktop/lastgubapassenger/guba_ticket_passenger/lib/redux/StoreProvider.tsx",
        lineNumber: 16,
        columnNumber: 10
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__753facf4._.js.map