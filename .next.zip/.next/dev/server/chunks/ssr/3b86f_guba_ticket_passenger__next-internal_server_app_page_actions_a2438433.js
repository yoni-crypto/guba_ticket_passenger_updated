module.exports = [
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3b86f_guba_ticket_passenger__next-internal_server_app_page_actions_a2438433.js.map