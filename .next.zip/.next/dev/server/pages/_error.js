var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/cfcca_f08dd44b._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/cfcca_03c9fbef._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/cfcca_next_79b9b646._.js")
R.m("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
