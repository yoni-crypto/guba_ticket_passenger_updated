(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/html2canvas/dist/html2canvas.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/html2canvas/dist/html2canvas.js [app-client] (ecmascript)");
    });
});
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/cfcca_dompurify_dist_purify_es_mjs_0f1c1e0c._.js",
  "static/chunks/cfcca_dompurify_dist_purify_es_mjs_ea1117ef._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/canvg/lib/index.es.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/cfcca_6870e072._.js",
  "static/chunks/cfcca_canvg_lib_index_es_ea1117ef.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/canvg/lib/index.es.js [app-client] (ecmascript)");
    });
});
}),
]);