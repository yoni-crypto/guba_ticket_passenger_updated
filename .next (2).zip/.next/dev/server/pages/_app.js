var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__983dd030._.js")
R.m("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/app.js [ssr] (ecmascript)").exports
