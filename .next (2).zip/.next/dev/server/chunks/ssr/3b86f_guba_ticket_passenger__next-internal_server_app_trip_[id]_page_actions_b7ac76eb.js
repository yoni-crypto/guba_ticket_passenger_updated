module.exports = [
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/.next-internal/server/app/trip/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3b86f_guba_ticket_passenger__next-internal_server_app_trip_%5Bid%5D_page_actions_b7ac76eb.js.map