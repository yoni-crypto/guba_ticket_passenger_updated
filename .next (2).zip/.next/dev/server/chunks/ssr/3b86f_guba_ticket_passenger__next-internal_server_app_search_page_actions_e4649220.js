module.exports = [
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/.next-internal/server/app/search/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3b86f_guba_ticket_passenger__next-internal_server_app_search_page_actions_e4649220.js.map