module.exports = [
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/.next-internal/server/app/my-tickets/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=80cd7_ticket_passenger__next-internal_server_app_my-tickets_page_actions_5338c9f0.js.map