module.exports = [
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/.next-internal/server/app/payment/success/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=0c77b_passenger__next-internal_server_app_payment_success_page_actions_7c966cab.js.map