module.exports = [
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/html2pdf.js/dist/html2pdf.js [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/cfcca_393efef9._.js",
  "server/chunks/ssr/cfcca_pako_dist_pako_esm_mjs_2dd4df2f._.js",
  "server/chunks/ssr/cfcca_jspdf_dist_jspdf_es_min_6a9bcc1e.js",
  "server/chunks/ssr/cfcca_html2canvas_dist_html2canvas_esm_ed265bd0.js",
  "server/chunks/ssr/cfcca_html2pdf_js_dist_html2pdf_8c0e2c79.js",
  "server/chunks/ssr/cfcca_4614bb20._.js",
  "server/chunks/ssr/[externals]_module_aa10390c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/html2pdf.js/dist/html2pdf.js [app-ssr] (ecmascript)");
    });
});
}),
];