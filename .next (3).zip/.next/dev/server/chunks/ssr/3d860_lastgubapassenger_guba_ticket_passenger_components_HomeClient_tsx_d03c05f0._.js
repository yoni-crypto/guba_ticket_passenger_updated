module.exports = [
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/components/HomeClient.tsx [app-rsc] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/3d860_lastgubapassenger_guba_ticket_passenger_components_HomeClient_tsx_f5690e78._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/components/HomeClient.tsx [app-rsc] (ecmascript, next/dynamic entry)");
    });
});
}),
];