module.exports = [
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/html2canvas/dist/html2canvas.esm.js [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/cfcca_html2canvas_dist_html2canvas_esm_ed265bd0.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/html2canvas/dist/html2canvas.esm.js [app-ssr] (ecmascript)");
    });
});
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/dompurify/dist/purify.es.mjs [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/cfcca_dompurify_dist_purify_es_mjs_5f4947fd._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/dompurify/dist/purify.es.mjs [app-ssr] (ecmascript)");
    });
});
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/canvg/lib/index.es.js [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/cfcca_e7df6d89._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/canvg/lib/index.es.js [app-ssr] (ecmascript)");
    });
});
}),
];