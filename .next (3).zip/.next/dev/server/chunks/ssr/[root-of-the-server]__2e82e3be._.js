module.exports = [
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/app/favicon.ico.mjs { IMAGE => \"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/app/favicon.ico.mjs { IMAGE => \"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/app/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/node_modules/next/dist/shared/lib/app-dynamic.js [app-rsc] (ecmascript)");
;
;
const HomeClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$lastgubapassenger$2f$guba_ticket_passenger$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/components/HomeClient.tsx [app-rsc] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/lastgubapassenger/guba_ticket_passenger/components/HomeClient.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
const __TURBOPACK__default__export__ = HomeClient;
}),
"[project]/Desktop/lastgubapassenger/guba_ticket_passenger/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/lastgubapassenger/guba_ticket_passenger/app/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__2e82e3be._.js.map