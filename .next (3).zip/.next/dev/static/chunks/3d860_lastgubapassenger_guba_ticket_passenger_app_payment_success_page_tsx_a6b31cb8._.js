(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_lastgubapassenger_guba_ticket_passenger_3b639ba4._.js",
  "static/chunks/cfcca_65154146._.js"
],
    source: "dynamic"
});
