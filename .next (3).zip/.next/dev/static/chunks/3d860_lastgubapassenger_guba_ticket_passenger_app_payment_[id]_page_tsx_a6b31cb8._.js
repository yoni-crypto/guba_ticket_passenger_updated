(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_lastgubapassenger_guba_ticket_passenger_08d03177._.js",
  "static/chunks/cfcca_d2063773._.js"
],
    source: "dynamic"
});
