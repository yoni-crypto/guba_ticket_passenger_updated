(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/cfcca_d042c8f0._.js",
  "static/chunks/Desktop_lastgubapassenger_guba_ticket_passenger_0ff2ca2a._.js",
  "static/chunks/cfcca_pako_dist_pako_esm_mjs_ebdf30ce._.js",
  "static/chunks/cfcca_jspdf_dist_jspdf_es_min_6925eeb1.js",
  "static/chunks/cfcca_jsbarcode_bin_aca975d0._.js",
  "static/chunks/cfcca_929ad9c4._.js"
],
    source: "dynamic"
});
